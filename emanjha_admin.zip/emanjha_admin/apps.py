from django.apps import AppConfig


class EmanjhaAdminConfig(AppConfig):
    name = 'emanjha_admin'
